

package com.codegen.repository;

import com.codegen.model.Juned;

import org.springframework.data.jpa.repository.JpaRepository;

public interface JunedRepository extends JpaRepository <Juned, Long>{

};
