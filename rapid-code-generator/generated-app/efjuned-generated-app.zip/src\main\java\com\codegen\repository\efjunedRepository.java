

package com.codegen.repository;

import com.codegen.model.efjuned;

import org.springframework.data.jpa.repository.JpaRepository;

public interface efjunedRepository extends JpaRepository <efjuned, Long>{

};
