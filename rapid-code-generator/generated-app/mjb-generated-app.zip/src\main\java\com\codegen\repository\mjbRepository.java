

package com.codegen.repository;

import com.codegen.model.mjb;

import org.springframework.data.jpa.repository.JpaRepository;

public interface mjbRepository extends JpaRepository <mjb, Long>{

};
